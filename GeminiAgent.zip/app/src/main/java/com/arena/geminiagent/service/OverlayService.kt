package com.arena.geminiagent.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings as AndroidSettings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import com.arena.geminiagent.R

/**
 * Floating draggable button that sits on top of all apps (including games).
 *
 *  - Tap            → arms the agent for a few seconds (so the next thing you
 *                     say is forwarded to Gemini).
 *  - Drag           → moves the bubble; small movement is treated as a tap.
 *
 * NOTE: This is intentionally **not** a foreground service. Android 14+ no
 * longer allows third-party apps to start a `specialUse` foreground service
 * without a Play-allowed declaration, and `TYPE_APPLICATION_OVERLAY` itself
 * does not require one. The bubble's lifecycle is owned by [AgentService] —
 * it is started/stopped from there, which holds the long-running FG state.
 */
class OverlayService : Service() {

    private var view: View? = null
    private var wm: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { teardown(); stopSelf() }
            else -> showBubble()
        }
        return START_STICKY
    }

    private fun showBubble() {
        if (view != null) return
        if (!AndroidSettings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission not granted; stopping")
            stopSelf(); return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_button, null) as FrameLayout
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40; y = 300
        }
        params = p

        var initialX = 0; var initialY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false
        val touchSlop = 12
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = p.x; initialY = p.y
                    touchX = e.rawX; touchY = e.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) {
                        moved = true
                    }
                    if (moved) {
                        p.x = initialX + dx
                        p.y = initialY + dy
                        try { wm?.updateViewLayout(view, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) AgentService.arm(this@OverlayService)
                    true
                }
                else -> false
            }
        }
        try {
            wm?.addView(v, p); view = v
        } catch (e: Exception) {
            Log.e(TAG, "addView failed: ${e.message}")
        }
    }

    private fun teardown() {
        try { view?.let { wm?.removeView(it) } } catch (_: Exception) {}
        view = null; params = null
    }

    override fun onDestroy() { teardown(); super.onDestroy() }

    companion object {
        private const val TAG = "OverlayService"
        const val ACTION_STOP = "com.arena.geminiagent.OVERLAY_STOP"

        fun start(context: Context) {
            // Plain (non-foreground) service — only valid because the host
            // AgentService is running in the foreground and keeps the process
            // alive while the bubble is visible.
            try {
                context.startService(Intent(context, OverlayService::class.java))
            } catch (e: Exception) {
                Log.w(TAG, "Could not start overlay: ${e.message}")
            }
        }

        fun stop(context: Context) {
            try {
                context.startService(
                    Intent(context, OverlayService::class.java).setAction(ACTION_STOP)
                )
            } catch (_: Exception) {}
        }
    }
}
