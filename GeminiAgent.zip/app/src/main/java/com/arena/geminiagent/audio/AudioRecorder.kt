package com.arena.geminiagent.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * Continuous microphone capture → 16-bit PCM @ 16 kHz mono.
 * Emits ~100 ms chunks via [pcmChunks]. Each chunk is exactly the size required
 * by the Gemini Live API (`audio/pcm;rate=16000`).
 *
 * Caller is responsible for gating which chunks are forwarded (e.g. only when
 * the wake word has fired, or always, depending on `onlyOnRequest` setting).
 */
class AudioRecorder {

    companion object {
        const val SAMPLE_RATE = 16_000
        const val CHANNEL = AudioFormat.CHANNEL_IN_MONO
        const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
        private const val TAG = "AudioRecorder"
        // 100 ms of 16-bit @ 16 kHz mono = 3200 bytes
        private const val CHUNK_BYTES = 3200
    }

    private val _pcmChunks = MutableSharedFlow<ByteArray>(extraBufferCapacity = 32)
    val pcmChunks: SharedFlow<ByteArray> = _pcmChunks.asSharedFlow()

    /** RMS level 0..1 for UI meters. */
    private val _level = MutableSharedFlow<Float>(extraBufferCapacity = 4)
    val level: SharedFlow<Float> = _level.asSharedFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var record: AudioRecord? = null

    @SuppressLint("MissingPermission")
    fun start() {
        if (job != null) return
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL, ENCODING)
            .coerceAtLeast(CHUNK_BYTES * 4)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE, CHANNEL, ENCODING, minBuf
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "AudioRecord ctor failed (permission?): ${e.message}")
            return
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord ctor failed: ${e.message}")
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord init failed (state=${rec.state})")
            try { rec.release() } catch (_: Exception) {}
            return
        }
        record = rec
        try {
            rec.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "startRecording failed: ${e.message}")
            try { rec.release() } catch (_: Exception) {}
            record = null
            return
        }
        job = scope.launch {
            val buf = ByteArray(CHUNK_BYTES)
            while (true) {
                val n = try { rec.read(buf, 0, buf.size) } catch (_: Exception) { -1 }
                if (n <= 0) {
                    if (n < 0) break // record was released
                    continue
                }
                val chunk = buf.copyOf(n)
                _pcmChunks.tryEmit(chunk)
                _level.tryEmit(rms(chunk))
            }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        try {
            record?.stop()
            record?.release()
        } catch (_: Exception) { }
        record = null
    }

    fun shutdown() {
        stop()
        scope.cancel()
    }

    private fun rms(buf: ByteArray): Float {
        var sum = 0.0
        var i = 0
        val count = buf.size / 2
        while (i < buf.size - 1) {
            val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
            val sample = if (s >= 32768) s - 65536 else s
            sum += sample.toDouble() * sample.toDouble()
            i += 2
        }
        val mean = if (count == 0) 0.0 else sum / count
        return (Math.sqrt(mean) / 32768.0).toFloat().coerceIn(0f, 1f)
    }
}
