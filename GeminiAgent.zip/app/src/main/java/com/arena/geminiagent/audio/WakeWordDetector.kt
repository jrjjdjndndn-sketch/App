package com.arena.geminiagent.audio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Lightweight wake-word detector built on Android's on-device SpeechRecognizer.
 *
 * Why this approach:
 *  - 100% on-device (Google's offline recognizer when available), no extra API key needed.
 *  - Works with Arabic and English.
 *  - Doesn't conflict with our parallel raw mic capture — Android multiplexes the mic
 *    on most modern devices (>= API 28) when both consumers use VOICE_RECOGNITION.
 *
 * Behaviour:
 *  - Listens continuously. On partial result, checks if any configured wake phrase
 *    appears as a substring (case-insensitive). If yes → emits Triggered with the
 *    REMAINDER of the utterance (so the user can say wake-word + question in one go).
 *  - Auto-restarts when the recognizer ends (timeout / silence).
 */
class WakeWordDetector(
    private val context: Context,
    private val phrases: List<String>,
    private val language: String = "ar-EG"
) : RecognitionListener {

    private val _events = MutableSharedFlow<Event>(extraBufferCapacity = 8)
    val events: SharedFlow<Event> = _events.asSharedFlow()

    sealed class Event {
        /** Wake word detected. [trailing] is anything spoken after the wake phrase. */
        data class Triggered(val trailing: String) : Event()
        object Error : Event()
    }

    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private val normalizedPhrases = phrases.map { normalize(it) }.filter { it.isNotEmpty() }

    fun start() {
        if (running) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "No on-device recognizer available — wake-word disabled")
            return
        }
        running = true
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).also {
            it.setRecognitionListener(this)
        }
        listenOnce()
    }

    fun stop() {
        running = false
        try { recognizer?.stopListening() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    private fun listenOnce() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) {
            Log.e(TAG, "startListening failed: ${e.message}")
        }
    }

    private fun restartLater() {
        if (!running) return
        recognizer?.let {
            try { it.cancel() } catch (_: Exception) {}
        }
        // Restart immediately
        listenOnce()
    }

    // ─── RecognitionListener ───
    override fun onPartialResults(partial: Bundle?) = check(partial)
    override fun onResults(results: Bundle?) {
        check(results)
        restartLater()
    }
    override fun onError(error: Int) {
        // Common: ERROR_NO_MATCH, ERROR_SPEECH_TIMEOUT → just restart silently.
        restartLater()
    }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    private fun check(bundle: Bundle?) {
        val list = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        for (raw in list) {
            val norm = normalize(raw)
            for (p in normalizedPhrases) {
                val idx = norm.indexOf(p)
                if (idx >= 0) {
                    val trailing = norm.substring(idx + p.length).trim()
                    _events.tryEmit(Event.Triggered(trailing))
                    return
                }
            }
        }
    }

    private fun normalize(s: String): String =
        s.lowercase()
            .replace("[إأآا]".toRegex(), "ا")
            .replace("ى", "ي")
            .replace("ة", "ه")
            .replace("[^a-z0-9\u0600-\u06FF ]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()

    companion object { private const val TAG = "WakeWord" }
}
