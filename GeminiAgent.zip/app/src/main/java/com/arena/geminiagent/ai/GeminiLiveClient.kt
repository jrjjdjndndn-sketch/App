package com.arena.geminiagent.ai

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.TimeUnit

/**
 * Gemini Live API client over WebSocket (BidiGenerateContent).
 *
 * Endpoint:
 *   wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=API_KEY
 *
 * Protocol:
 *  1) Client sends `setup` (model, systemInstruction, generationConfig, …).
 *  2) Server replies with `setupComplete`.
 *  3) Bidi streaming via `realtimeInput` (audio/video/text) ⇄ `serverContent`.
 *
 * IMPORTANT: All field names on the wire are **camelCase** (Google AIP-127 /
 * default proto-JSON mapping). The official ai.google.dev/api/live reference
 * spells them as `realtimeInput`, `mimeType`, `systemInstruction`,
 * `generationConfig`, `speechConfig`, `voiceConfig`, `prebuiltVoiceConfig`,
 * `voiceName`, `languageCode`, `responseModalities`, `mediaResolution`,
 * `realtimeInputConfig`, `automaticActivityDetection`, `inputAudioTranscription`,
 * `outputAudioTranscription`, `activityStart`, `activityEnd`.
 *
 * Audio in : 16-bit PCM little-endian, 16 kHz, mono → MIME `audio/pcm;rate=16000`.
 * Audio out: 16-bit PCM little-endian, 24 kHz, mono — feed straight to AudioTrack.
 * Video    : JPEG frames (image/jpeg), ≤ 1 FPS.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val systemInstruction: String,
    private val voice: String = "Puck",
    private val languageCode: String = "ar-EG"
) {

    enum class State { Idle, Connecting, Ready, Reconnecting, Closed, Error }

    private val _state = MutableStateFlow(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    /** Raw 24kHz PCM chunks received from the model (to be played back). */
    private val _audioOut = MutableSharedFlow<ByteArray>(extraBufferCapacity = 64)
    val audioOut: SharedFlow<ByteArray> = _audioOut.asSharedFlow()

    /** Transcripts (both input from user and output from model). */
    private val _transcripts = MutableSharedFlow<Transcript>(extraBufferCapacity = 32)
    val transcripts: SharedFlow<Transcript> = _transcripts.asSharedFlow()

    /** Server signals the user interrupted — caller should flush the playback queue. */
    private val _interrupted = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val interrupted: SharedFlow<Unit> = _interrupted.asSharedFlow()

    data class Transcript(val text: String, val fromUser: Boolean, val final: Boolean)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var keepAliveJob: Job? = null
    private var ws: WebSocket? = null
    private var reconnectAttempt = 0
    private var manuallyClosed = false

    private val httpClient = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // streaming
        .build()

    // ───────────────────────────── Public API ─────────────────────────────

    fun connect() {
        if (_state.value == State.Connecting || _state.value == State.Ready) return
        manuallyClosed = false
        openSocket()
    }

    fun close() {
        manuallyClosed = true
        keepAliveJob?.cancel()
        try { ws?.close(1000, "client_close") } catch (_: Exception) {}
        ws = null
        _state.value = State.Closed
        scope.cancel()
    }

    /** Send a raw PCM audio chunk (16-bit LE, 16 kHz, mono). Fire-and-forget. */
    fun sendAudio(pcm16: ByteArray) {
        val w = ws ?: return
        if (_state.value != State.Ready) return
        val b64 = Base64.encodeToString(pcm16, Base64.NO_WRAP)
        val msg = buildJsonObject {
            put("realtimeInput", buildJsonObject {
                put("audio", buildJsonObject {
                    put("data", b64)
                    put("mimeType", "audio/pcm;rate=16000")
                })
            })
        }
        try { w.send(msg.toString()) } catch (_: Exception) {}
    }

    /** Send one screen/video frame as JPEG bytes. */
    fun sendVideoFrame(jpegBytes: ByteArray) {
        val w = ws ?: return
        if (_state.value != State.Ready) return
        val b64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
        val msg = buildJsonObject {
            put("realtimeInput", buildJsonObject {
                put("video", buildJsonObject {
                    put("data", b64)
                    put("mimeType", "image/jpeg")
                })
            })
        }
        try { w.send(msg.toString()) } catch (_: Exception) {}
    }

    /** Send a text turn (push-to-talk fallback). */
    fun sendText(text: String) {
        val w = ws ?: return
        if (_state.value != State.Ready) return
        val msg = buildJsonObject {
            put("realtimeInput", buildJsonObject {
                put("text", text)
            })
        }
        try { w.send(msg.toString()) } catch (_: Exception) {}
    }

    /**
     * Explicitly mark start of a user speech segment. Only effective when
     * `automaticActivityDetection.disabled = true` in setup. With our default
     * (VAD enabled), these signals are accepted-but-ignored — harmless to call.
     */
    fun sendActivityStart() {
        val w = ws ?: return
        if (_state.value != State.Ready) return
        try {
            w.send(buildJsonObject {
                put("realtimeInput", buildJsonObject {
                    put("activityStart", buildJsonObject {})
                })
            }.toString())
        } catch (_: Exception) {}
    }

    fun sendActivityEnd() {
        val w = ws ?: return
        if (_state.value != State.Ready) return
        try {
            w.send(buildJsonObject {
                put("realtimeInput", buildJsonObject {
                    put("activityEnd", buildJsonObject {})
                })
            }.toString())
        } catch (_: Exception) {}
    }

    // ───────────────────────────── Internals ─────────────────────────────

    private fun openSocket() {
        _state.value = State.Connecting
        val url =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()
        ws = httpClient.newWebSocket(request, listener)
    }

    private fun scheduleReconnect() {
        if (manuallyClosed) return
        reconnectAttempt++
        val delayMs = (1000L * (1 shl reconnectAttempt.coerceAtMost(5))).coerceAtMost(30_000L)
        Log.w(TAG, "Reconnecting in ${delayMs}ms (attempt $reconnectAttempt)")
        _state.value = State.Reconnecting
        scope.launch {
            delay(delayMs)
            if (!manuallyClosed) openSocket()
        }
    }

    /**
     * Build the initial `setup` message per the official Live API schema.
     * See: https://ai.google.dev/api/live#bidigeneratecontentsetup
     */
    private fun sendSetup(ws: WebSocket) {
        val setup = buildJsonObject {
            put("setup", buildJsonObject {
                put("model", "models/$model")
                put("systemInstruction", buildJsonObject {
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", systemInstruction) })
                    })
                })
                put("generationConfig", buildJsonObject {
                    put("responseModalities", buildJsonArray { add("AUDIO") })
                    put("speechConfig", buildJsonObject {
                        put("voiceConfig", buildJsonObject {
                            put("prebuiltVoiceConfig", buildJsonObject {
                                put("voiceName", voice)
                            })
                        })
                        put("languageCode", languageCode)
                    })
                    // Lower-res screen frames → fewer tokens, faster turns.
                    put("mediaResolution", "MEDIA_RESOLUTION_LOW")
                })
                // Transcribe both directions so the UI can show captions.
                put("inputAudioTranscription", buildJsonObject {})
                put("outputAudioTranscription", buildJsonObject {})
                // Let the server's automatic VAD decide when a turn starts/ends.
                put("realtimeInputConfig", buildJsonObject {
                    put("automaticActivityDetection", buildJsonObject {
                        put("disabled", false)
                    })
                })
            })
        }
        try { ws.send(setup.toString()) } catch (e: Exception) {
            Log.e(TAG, "send setup failed: ${e.message}")
        }
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.i(TAG, "WS open")
            sendSetup(webSocket)
            keepAliveJob?.cancel()
            keepAliveJob = scope.launch {
                while (true) {
                    delay(15_000)
                    try { webSocket.send(ByteString.EMPTY) } catch (_: Exception) {}
                }
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) = handleJson(text)
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handleJson(bytes.utf8())

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.w(TAG, "WS closing: $code $reason")
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.w(TAG, "WS closed: $code $reason")
            keepAliveJob?.cancel()
            if (!manuallyClosed) {
                _state.value = State.Closed
                scheduleReconnect()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "WS failure: ${t.message}", t)
            keepAliveJob?.cancel()
            _state.value = State.Error
            if (!manuallyClosed) scheduleReconnect()
        }
    }

    private fun handleJson(raw: String) {
        if (raw.isBlank()) return
        try {
            val json = Json.parseToJsonElement(raw) as? JsonObject ?: return

            // setupComplete → connection is ready
            json["setupComplete"]?.let {
                Log.i(TAG, "setupComplete")
                _state.value = State.Ready
                reconnectAttempt = 0
                return
            }

            // serverContent → audio chunks, transcripts, turn signals, …
            val serverContent = json["serverContent"] as? JsonObject ?: return

            // Interruption (boolean)
            (serverContent["interrupted"] as? JsonPrimitive)?.booleanOrNull?.let { b ->
                if (b) scope.launch { _interrupted.emit(Unit) }
            }

            // Audio + text parts inside modelTurn.parts
            val modelTurn = serverContent["modelTurn"] as? JsonObject
            (modelTurn?.get("parts") as? JsonArray)?.forEach { part ->
                val partObj = part as? JsonObject ?: return@forEach
                val inline = partObj["inlineData"] as? JsonObject
                if (inline != null) {
                    val mime = (inline["mimeType"] as? JsonPrimitive)?.content
                    val data = (inline["data"] as? JsonPrimitive)?.content
                    if (data != null && mime != null && mime.startsWith("audio/")) {
                        val pcm = try { Base64.decode(data, Base64.DEFAULT) } catch (_: Exception) { null }
                        if (pcm != null) scope.launch { _audioOut.emit(pcm) }
                    }
                }
                val txt = (partObj["text"] as? JsonPrimitive)?.content
                if (!txt.isNullOrEmpty()) {
                    scope.launch {
                        _transcripts.emit(Transcript(txt, fromUser = false, final = false))
                    }
                }
            }

            // Standalone transcripts (sent independently of modelTurn).
            (serverContent["inputTranscription"] as? JsonObject)?.let {
                val t = (it["text"] as? JsonPrimitive)?.content
                if (!t.isNullOrEmpty()) scope.launch {
                    _transcripts.emit(Transcript(t, fromUser = true, final = false))
                }
            }
            (serverContent["outputTranscription"] as? JsonObject)?.let {
                val t = (it["text"] as? JsonPrimitive)?.content
                if (!t.isNullOrEmpty()) scope.launch {
                    _transcripts.emit(Transcript(t, fromUser = false, final = false))
                }
            }

            // turnComplete → flush UI state
            (serverContent["turnComplete"] as? JsonPrimitive)?.booleanOrNull?.let { b ->
                if (b) scope.launch {
                    _transcripts.emit(Transcript("", fromUser = false, final = true))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Bad JSON: ${e.message}\n${raw.take(500)}")
        }
    }

    companion object { private const val TAG = "GeminiLive" }
}
