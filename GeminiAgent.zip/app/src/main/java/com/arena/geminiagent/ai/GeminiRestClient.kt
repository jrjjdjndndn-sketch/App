package com.arena.geminiagent.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Simple REST helper for the heavy-reasoning model (Gemini 3.5 Flash).
 *
 * Use this when the user asks a complex question about the current screen
 * that benefits from full "thinking" — the Live model is tuned for low-latency
 * conversation and uses `thinking_budget=0` for snappy turns.
 *
 * The Live agent can call into this and feed the spoken answer back through
 * its own audio output by re-sending the text via [GeminiLiveClient.sendText].
 */
class GeminiRestClient(
    private val apiKey: String,
    private val model: String
) {

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Single-shot generation with optional inline image (JPEG bytes).
     * Returns the model's text response.
     */
    suspend fun ask(prompt: String, jpegImage: ByteArray? = null): String = withContext(Dispatchers.IO) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val partsArr: JsonArray = buildJsonArray {
            if (jpegImage != null) {
                add(buildJsonObject {
                    put("inline_data", buildJsonObject {
                        put("mime_type", "image/jpeg")
                        put("data", Base64.encodeToString(jpegImage, Base64.NO_WRAP))
                    })
                })
            }
            add(buildJsonObject { put("text", prompt) })
        }

        val body = buildJsonObject {
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("role", "user")
                    put("parts", partsArr)
                })
            })
            put("generationConfig", buildJsonObject {
                put("temperature", 0.7)
                put("maxOutputTokens", 1024)
            })
        }.toString()

        val req = Request.Builder()
            .url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { resp ->
            val s = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("HTTP ${resp.code}: $s")
            val obj = Json.parseToJsonElement(s).jsonObject
            obj["candidates"]?.jsonArray?.firstOrNull()
                ?.jsonObject?.get("content")
                ?.jsonObject?.get("parts")
                ?.jsonArray?.joinToString("") {
                    it.jsonObject["text"]?.jsonPrimitive?.content.orEmpty()
                } ?: ""
        }
    }
}
