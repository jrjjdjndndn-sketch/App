package com.arena.geminiagent.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Encrypted preferences for API key + user-tunable agent settings.
 * Uses AndroidX Security Crypto so the API key is encrypted at rest with
 * a key bound to the Android Keystore.
 */
class Settings(context: Context) {

    private val prefs: SharedPreferences = run {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ---- API key ----
    var apiKey: String
        get() = prefs.getString(K_API_KEY, "") ?: ""
        set(v) = prefs.edit().putString(K_API_KEY, v).apply()

    // ---- Model selection ----
    /** Live API model (for streaming audio+video conversation). */
    var liveModel: String
        get() = prefs.getString(K_LIVE_MODEL, DEFAULT_LIVE_MODEL) ?: DEFAULT_LIVE_MODEL
        set(v) = prefs.edit().putString(K_LIVE_MODEL, v).apply()

    /** Heavy-thinking REST model (Gemini 3.5 Flash). */
    var thinkModel: String
        get() = prefs.getString(K_THINK_MODEL, DEFAULT_THINK_MODEL) ?: DEFAULT_THINK_MODEL
        set(v) = prefs.edit().putString(K_THINK_MODEL, v).apply()

    // ---- Behaviour ----
    /** Wake word the agent listens for (e.g. "يا جيمناي"). */
    var wakeWord: String
        get() = prefs.getString(K_WAKE_WORD, "يا جيمناي") ?: "يا جيمناي"
        set(v) = prefs.edit().putString(K_WAKE_WORD, v).apply()

    /** Screen frames per second to send (Live API max = 1 FPS). */
    var screenFps: Float
        get() = prefs.getFloat(K_FPS, 1.0f)
        set(v) = prefs.edit().putFloat(K_FPS, v).apply()

    /** Native Gemini voice name. */
    var voice: String
        get() = prefs.getString(K_VOICE, "Puck") ?: "Puck"
        set(v) = prefs.edit().putString(K_VOICE, v).apply()

    /** Primary language hint sent to the model. */
    var languageHint: String
        get() = prefs.getString(K_LANG, "ar") ?: "ar"
        set(v) = prefs.edit().putString(K_LANG, v).apply()

    /** Only respond when addressed (wake word / button). */
    var onlyOnRequest: Boolean
        get() = prefs.getBoolean(K_ON_REQUEST, true)
        set(v) = prefs.edit().putBoolean(K_ON_REQUEST, v).apply()

    /** Send screen at all? */
    var streamScreen: Boolean
        get() = prefs.getBoolean(K_STREAM_SCREEN, true)
        set(v) = prefs.edit().putBoolean(K_STREAM_SCREEN, v).apply()

    /** Show floating overlay button? */
    var showOverlay: Boolean
        get() = prefs.getBoolean(K_OVERLAY, true)
        set(v) = prefs.edit().putBoolean(K_OVERLAY, v).apply()

    companion object {
        private const val K_API_KEY = "api_key"
        private const val K_LIVE_MODEL = "live_model"
        private const val K_THINK_MODEL = "think_model"
        private const val K_WAKE_WORD = "wake_word"
        private const val K_FPS = "screen_fps"
        private const val K_VOICE = "voice"
        private const val K_LANG = "lang"
        private const val K_ON_REQUEST = "on_request"
        private const val K_STREAM_SCREEN = "stream_screen"
        private const val K_OVERLAY = "overlay"

        // Live API model — recommended one as of June 2026 (per official Gemini skills docs).
        // The 3.5 family Live preview shipped under the "3.1-flash-live-preview" track and
        // continues to receive the newest native-audio capabilities. Update here when Google
        // promotes it to e.g. gemini-3.5-flash-live.
        const val DEFAULT_LIVE_MODEL = "gemini-3.1-flash-live-preview"

        // Heavy-reasoning REST model — Google I/O 2026 flagship Flash tier.
        const val DEFAULT_THINK_MODEL = "gemini-3.5-flash"

        val AVAILABLE_VOICES = listOf(
            "Puck", "Charon", "Kore", "Fenrir", "Aoede",
            "Leda", "Orus", "Zephyr"
        )
    }
}
