package com.arena.geminiagent.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.arena.geminiagent.App
import com.arena.geminiagent.MainActivity
import com.arena.geminiagent.R
import com.arena.geminiagent.ai.GeminiLiveClient
import com.arena.geminiagent.ai.SystemPrompt
import com.arena.geminiagent.audio.AudioPlayer
import com.arena.geminiagent.audio.AudioRecorder
import com.arena.geminiagent.audio.WakeWordDetector
import com.arena.geminiagent.data.Settings
import com.arena.geminiagent.screen.ScreenCapturer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Long-running Foreground service that wires together:
 *   • [GeminiLiveClient]  — WebSocket bidi stream
 *   • [AudioRecorder]     — 16 kHz PCM mic capture
 *   • [AudioPlayer]       — 24 kHz PCM playback
 *   • [ScreenCapturer]    — JPEG screen frames @ ≤ 1 FPS
 *   • [WakeWordDetector]  — on-device wake-word ("يا جيمناي")
 *
 * Modes:
 *   • If [Settings.onlyOnRequest] is true (default), mic chunks are NOT
 *     forwarded to Gemini until the user either:
 *       (a) says the wake word, or
 *       (b) taps the floating overlay button (PTT).
 *     A short "armed window" then forwards audio for [ARMED_WINDOW_MS] ms,
 *     extended every time the user keeps talking.
 *
 *   • If [Settings.onlyOnRequest] is false, mic is always live and Gemini's
 *     own VAD decides when to respond.
 *
 * Screen frames are always forwarded when [Settings.streamScreen] is true and
 * the WebSocket is Ready — they're cheap context that lets the model answer
 * "what is this thing on screen?" instantly.
 */
class AgentService : Service() {

    inner class LocalBinder : Binder() { val service: AgentService = this@AgentService }
    private val binder = LocalBinder()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // ── Components ──
    private lateinit var settings: Settings
    private val recorder = AudioRecorder()
    private val player = AudioPlayer()
    private var live: GeminiLiveClient? = null
    private var screen: ScreenCapturer? = null
    private var wake: WakeWordDetector? = null
    private var mediaProjection: MediaProjection? = null

    // ── Gating ──
    private val _status = MutableStateFlow(Status.Idle)
    val status: StateFlow<Status> = _status.asStateFlow()
    enum class Status { Idle, Connecting, Listening, Speaking, Thinking, Error }

    private val _captionFlow = MutableStateFlow("")
    val caption: StateFlow<String> = _captionFlow.asStateFlow()

    @Volatile private var armedUntil: Long = 0L
    private var armingJob: Job? = null

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        settings = Settings(this)
        startInForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        when (action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> { stopAll(); stopSelf() }
            ACTION_ARM -> arm(durationMs = ARMED_WINDOW_MS)
            ACTION_SEND_TEXT -> {
                val text = intent?.getStringExtra(EXTRA_TEXT).orEmpty()
                if (text.isNotBlank()) live?.sendText(text)
            }
        }
        return START_STICKY
    }

    private fun handleStart(intent: Intent?) {
        if (live != null) return // already running

        // 1) Media projection (optional — null means no screen streaming)
        val resultCode = intent?.getIntExtra(EXTRA_MP_CODE, 0) ?: 0
        val dataIntent: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            intent?.getParcelableExtra(EXTRA_MP_INTENT, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_MP_INTENT)

        if (resultCode != 0 && dataIntent != null && settings.streamScreen) {
            mediaProjection = ScreenCapturer.fromActivityResult(this, resultCode, dataIntent)
        }

        val apiKey = settings.apiKey
        if (apiKey.isBlank()) {
            Log.e(TAG, "No API key set — aborting")
            _status.value = Status.Error
            return
        }

        // 2) Build Live client
        val sys = SystemPrompt.build(
            wakeWord = settings.wakeWord,
            languageHint = settings.languageHint
        )
        val client = GeminiLiveClient(
            apiKey = apiKey,
            model = settings.liveModel,
            systemInstruction = sys,
            voice = settings.voice,
            languageCode = if (settings.languageHint == "ar") "ar-EG" else "en-US"
        )
        live = client
        _status.value = Status.Connecting
        client.connect()

        // 3) Start audio I/O
        player.start()
        recorder.start()

        // 4) Wire flows
        scope.launch {
            client.state.collect { st ->
                _status.value = when (st) {
                    GeminiLiveClient.State.Ready -> Status.Listening
                    GeminiLiveClient.State.Connecting,
                    GeminiLiveClient.State.Reconnecting -> Status.Connecting
                    GeminiLiveClient.State.Error -> Status.Error
                    GeminiLiveClient.State.Closed -> Status.Idle
                    GeminiLiveClient.State.Idle -> Status.Idle
                }
            }
        }
        scope.launch {
            client.audioOut.collect { pcm ->
                _status.value = Status.Speaking
                player.enqueue(pcm)
            }
        }
        scope.launch {
            client.interrupted.collect {
                player.flush()
            }
        }
        scope.launch {
            client.transcripts.collect { t ->
                if (t.text.isNotEmpty()) {
                    val prefix = if (t.fromUser) "أنت: " else "🤖 "
                    _captionFlow.value = prefix + t.text
                }
                if (t.final && !t.fromUser) {
                    _status.value = Status.Listening
                }
            }
        }
        scope.launch {
            recorder.pcmChunks.collect { chunk ->
                if (!settings.onlyOnRequest || System.currentTimeMillis() < armedUntil) {
                    client.sendAudio(chunk)
                    // While armed, extend the window if the user keeps speaking
                    if (settings.onlyOnRequest) {
                        val rms = computeRms(chunk)
                        if (rms > SPEECH_RMS_THRESHOLD) {
                            armedUntil = System.currentTimeMillis() + ARMED_EXTEND_MS
                        }
                    }
                }
            }
        }

        // 5) Wake word
        wake = WakeWordDetector(
            this,
            phrases = listOf(settings.wakeWord, "يا جيمناي", "Hey Gemini", "جيمناي"),
            language = if (settings.languageHint == "ar") "ar-EG" else "en-US"
        )
        wake?.start()
        scope.launch {
            wake?.events?.collect { ev ->
                if (ev is WakeWordDetector.Event.Triggered) {
                    Log.i(TAG, "Wake word fired; trailing='${ev.trailing}'")
                    arm(ARMED_WINDOW_MS)
                    if (ev.trailing.isNotBlank()) {
                        // Pass any accompanying text directly so model can answer without
                        // waiting for the next mic chunk.
                        client.sendText(ev.trailing)
                    }
                }
            }
        }

        // 6) Screen capture (optional)
        mediaProjection?.let { mp ->
            val sc = ScreenCapturer(this, mp, fps = settings.screenFps)
            screen = sc
            sc.start()
            scope.launch {
                sc.frames.collect { jpeg -> client.sendVideoFrame(jpeg) }
            }
        }
    }

    /** Open the gate for [durationMs] so mic audio is forwarded to Gemini. */
    fun arm(durationMs: Long) {
        armedUntil = System.currentTimeMillis() + durationMs
        live?.sendActivityStart()
        armingJob?.cancel()
        armingJob = scope.launch {
            while (System.currentTimeMillis() < armedUntil) {
                delay(200)
            }
            live?.sendActivityEnd()
        }
    }

    private fun stopAll() {
        try { wake?.stop() } catch (_: Exception) {}
        try { screen?.shutdown() } catch (_: Exception) {}
        try { recorder.shutdown() } catch (_: Exception) {}
        try { player.shutdown() } catch (_: Exception) {}
        try { live?.close() } catch (_: Exception) {}
        live = null; screen = null; wake = null
        mediaProjection = null
        scope.cancel()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    // ─── Foreground notification ───
    private fun startInForeground() {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, AgentService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, App.CHANNEL_AGENT)
            .setSmallIcon(R.drawable.ic_agent)
            .setContentTitle(getString(R.string.notif_agent_title))
            .setContentText(getString(R.string.notif_agent_text))
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_agent, "إيقاف", stopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(NOTIF_ID, notif, type)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun computeRms(buf: ByteArray): Float {
        var sum = 0.0; var i = 0; val n = buf.size / 2
        while (i < buf.size - 1) {
            val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
            val v = if (s >= 32768) s - 65536 else s
            sum += v.toDouble() * v; i += 2
        }
        return if (n == 0) 0f else (Math.sqrt(sum / n) / 32768.0).toFloat()
    }

    companion object {
        private const val TAG = "AgentService"
        private const val NOTIF_ID = 4242

        const val ACTION_START = "com.arena.geminiagent.START"
        const val ACTION_STOP = "com.arena.geminiagent.STOP"
        const val ACTION_ARM = "com.arena.geminiagent.ARM"
        const val ACTION_SEND_TEXT = "com.arena.geminiagent.SEND_TEXT"

        const val EXTRA_MP_CODE = "mp_code"
        const val EXTRA_MP_INTENT = "mp_intent"
        const val EXTRA_TEXT = "text"

        const val ARMED_WINDOW_MS = 6_000L     // initial gate after wake word / tap
        const val ARMED_EXTEND_MS = 3_000L     // each time user keeps speaking
        const val SPEECH_RMS_THRESHOLD = 0.02f

        fun start(context: Context, mpCode: Int, mpData: Intent?) {
            val i = Intent(context, AgentService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_MP_CODE, mpCode)
                if (mpData != null) putExtra(EXTRA_MP_INTENT, mpData)
            }
            context.startForegroundService(i)
        }
        fun stop(context: Context) {
            context.startService(
                Intent(context, AgentService::class.java).setAction(ACTION_STOP)
            )
        }
        fun arm(context: Context) {
            context.startService(
                Intent(context, AgentService::class.java).setAction(ACTION_ARM)
            )
        }
        fun sendText(context: Context, text: String) {
            context.startService(
                Intent(context, AgentService::class.java)
                    .setAction(ACTION_SEND_TEXT)
                    .putExtra(EXTRA_TEXT, text)
            )
        }
    }
}
