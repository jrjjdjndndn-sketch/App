package com.arena.geminiagent.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.arena.geminiagent.App
import com.arena.geminiagent.MainActivity
import com.arena.geminiagent.R
import com.arena.geminiagent.ai.GeminiLiveClient
import com.arena.geminiagent.ai.SystemPrompt
import com.arena.geminiagent.audio.AudioPlayer
import com.arena.geminiagent.audio.AudioRecorder
import com.arena.geminiagent.audio.WakeWordDetector
import com.arena.geminiagent.data.Settings
import com.arena.geminiagent.screen.ScreenCapturer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Long-running Foreground service that wires together:
 *   • [GeminiLiveClient]  — WebSocket bidi stream
 *   • [AudioRecorder]     — 16 kHz PCM mic capture
 *   • [AudioPlayer]       — 24 kHz PCM playback
 *   • [ScreenCapturer]    — JPEG screen frames @ ≤ 1 FPS
 *   • [WakeWordDetector]  — on-device wake-word ("يا جيمناي")
 *
 * Modes:
 *   • If [Settings.onlyOnRequest] is true (default), mic chunks are NOT
 *     forwarded to Gemini until the user either:
 *       (a) says the wake word, or
 *       (b) taps the floating overlay button (PTT).
 *     A short "armed window" then forwards audio for [ARMED_WINDOW_MS] ms,
 *     extended every time the user keeps talking.
 *
 *   • If [Settings.onlyOnRequest] is false, mic is always live and Gemini's
 *     own VAD decides when to respond.
 *
 * Screen frames are always forwarded when [Settings.streamScreen] is true and
 * the WebSocket is Ready — they're cheap context that lets the model answer
 * "what is this thing on screen?" instantly.
 *
 * Android 14+ FG-type sequencing:
 *   onCreate()      → startForeground(MICROPHONE)
 *   handleStart()   → (if projection granted) startForeground(MICROPHONE|MEDIA_PROJECTION)
 *   stopAll()       → release everything, allow a fresh start later
 */
class AgentService : Service() {

    inner class LocalBinder : Binder() { val service: AgentService = this@AgentService }
    private val binder = LocalBinder()

    /** Recreated on every start so that a prior stop() doesn't poison new launches. */
    private var scope: CoroutineScope = newScope()
    private fun newScope() = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // ── Components (recreated on every start to avoid stale scopes) ──
    private lateinit var settings: Settings
    private var recorder: AudioRecorder? = null
    private var player: AudioPlayer? = null
    private var live: GeminiLiveClient? = null
    private var screen: ScreenCapturer? = null
    private var wake: WakeWordDetector? = null
    private var mediaProjection: MediaProjection? = null

    // ── Public state ──
    private val _status = MutableStateFlow(Status.Idle)
    val status: StateFlow<Status> = _status.asStateFlow()
    enum class Status { Idle, Connecting, Listening, Speaking, Thinking, Error }

    private val _captionFlow = MutableStateFlow("")
    val caption: StateFlow<String> = _captionFlow.asStateFlow()

    // ── Wake-word / PTT gating ──
    @Volatile private var armedUntil: Long = 0L
    private var armingJob: Job? = null
    @Volatile private var armActive: Boolean = false

    /** True after handleStart() succeeded; resets after stopAll(). */
    private var running = false

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        settings = Settings(this)
        // Start with MICROPHONE only — we don't yet have a MediaProjection.
        startInForeground(includeProjection = false)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        when (action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> { stopAll(); stopSelf() }
            ACTION_ARM -> arm(ARMED_WINDOW_MS)
            ACTION_SEND_TEXT -> {
                val text = intent?.getStringExtra(EXTRA_TEXT).orEmpty()
                if (text.isNotBlank()) live?.sendText(text)
            }
        }
        return START_STICKY
    }

    private fun handleStart(intent: Intent?) {
        if (running) {
            Log.i(TAG, "handleStart: already running, ignoring")
            return
        }

        val apiKey = settings.apiKey
        if (apiKey.isBlank()) {
            Log.e(TAG, "No API key set — aborting start")
            _status.value = Status.Error
            return
        }

        // Make sure we have a fresh scope (a previous stop may have cancelled the old one).
        if (scope.coroutineContext[Job]?.isActive != true) scope = newScope()

        // 1) Media projection — optional. Must be created BEFORE we can promote
        // the foreground service type to include MEDIA_PROJECTION.
        val resultCode = intent?.getIntExtra(EXTRA_MP_CODE, 0) ?: 0
        val dataIntent: Intent? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                intent?.getParcelableExtra(EXTRA_MP_INTENT, Intent::class.java)
            else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_MP_INTENT)

        if (resultCode != 0 && dataIntent != null && settings.streamScreen) {
            // Promote FG type FIRST (Android 14+ requires the type to be set
            // before getMediaProjection succeeds; some OEMs are strict).
            startInForeground(includeProjection = true)
            mediaProjection = try {
                ScreenCapturer.fromActivityResult(this, resultCode, dataIntent)
            } catch (e: Exception) {
                Log.e(TAG, "getMediaProjection failed: ${e.message}")
                null
            }
        }

        // 2) Build Live client
        val sys = SystemPrompt.build(
            wakeWord = settings.wakeWord,
            languageHint = settings.languageHint
        )
        val client = GeminiLiveClient(
            apiKey = apiKey,
            model = settings.liveModel,
            systemInstruction = sys,
            voice = settings.voice,
            languageCode = if (settings.languageHint == "ar") "ar-EG" else "en-US"
        )
        live = client
        _status.value = Status.Connecting
        client.connect()

        // 3) Start audio I/O (fresh instances every time)
        val pl = AudioPlayer().also { it.start() }
        player = pl
        val rec = AudioRecorder().also { it.start() }
        recorder = rec

        // 4) Wire flows
        scope.launch {
            client.state.collect { st ->
                _status.value = when (st) {
                    GeminiLiveClient.State.Ready -> Status.Listening
                    GeminiLiveClient.State.Connecting,
                    GeminiLiveClient.State.Reconnecting -> Status.Connecting
                    GeminiLiveClient.State.Error -> Status.Error
                    GeminiLiveClient.State.Closed -> Status.Idle
                    GeminiLiveClient.State.Idle -> Status.Idle
                }
            }
        }
        scope.launch {
            client.audioOut.collect { pcm ->
                _status.value = Status.Speaking
                pl.enqueue(pcm)
            }
        }
        scope.launch {
            client.interrupted.collect { pl.flush() }
        }
        scope.launch {
            client.transcripts.collect { t ->
                if (t.text.isNotEmpty()) {
                    val prefix = if (t.fromUser) "أنت: " else "🤖 "
                    _captionFlow.value = prefix + t.text
                }
                if (t.final && !t.fromUser) {
                    _status.value = Status.Listening
                }
            }
        }
        scope.launch {
            rec.pcmChunks.collect { chunk ->
                if (!settings.onlyOnRequest || System.currentTimeMillis() < armedUntil) {
                    client.sendAudio(chunk)
                    // Extend the gate while user is still speaking.
                    if (settings.onlyOnRequest && computeRms(chunk) > SPEECH_RMS_THRESHOLD) {
                        armedUntil = System.currentTimeMillis() + ARMED_EXTEND_MS
                    }
                }
            }
        }

        // 5) Wake word
        val w = WakeWordDetector(
            this,
            phrases = listOf(settings.wakeWord, "يا جيمناي", "Hey Gemini", "جيمناي"),
            language = if (settings.languageHint == "ar") "ar-EG" else "en-US"
        )
        wake = w
        w.start()
        scope.launch {
            w.events.collect { ev ->
                if (ev is WakeWordDetector.Event.Triggered) {
                    Log.i(TAG, "Wake word fired; trailing='${ev.trailing}'")
                    arm(ARMED_WINDOW_MS)
                    if (ev.trailing.isNotBlank()) client.sendText(ev.trailing)
                }
            }
        }

        // 6) Screen capture (optional)
        mediaProjection?.let { mp ->
            val sc = ScreenCapturer(this, mp, fps = settings.screenFps)
            screen = sc
            sc.start()
            scope.launch {
                sc.frames.collect { jpeg -> client.sendVideoFrame(jpeg) }
            }
        }

        running = true
    }

    /**
     * Open the gate for [durationMs] ms so mic audio is forwarded to Gemini.
     * Cancels any previous gating job to avoid a stale sendActivityEnd
     * firing after a fresh start.
     */
    fun arm(durationMs: Long) {
        armedUntil = System.currentTimeMillis() + durationMs
        val client = live ?: return
        if (!armActive) {
            armActive = true
            client.sendActivityStart()
        }
        armingJob?.cancel()
        armingJob = scope.launch {
            while (System.currentTimeMillis() < armedUntil) {
                delay(200)
            }
            armActive = false
            client.sendActivityEnd()
        }
    }

    private fun stopAll() {
        running = false
        armActive = false
        try { armingJob?.cancel() } catch (_: Exception) {}
        try { wake?.stop() } catch (_: Exception) {}
        try { screen?.shutdown() } catch (_: Exception) {}
        try { recorder?.shutdown() } catch (_: Exception) {}
        try { player?.shutdown() } catch (_: Exception) {}
        try { live?.close() } catch (_: Exception) {}
        live = null; screen = null; wake = null
        recorder = null; player = null
        mediaProjection = null
        try { scope.cancel() } catch (_: Exception) {}
        // Replace scope so any subsequent start gets a fresh one.
        scope = newScope()
        _status.value = Status.Idle
        _captionFlow.value = ""
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    // ─── Foreground notification ───────────────────────────────────────────
    private fun startInForeground(includeProjection: Boolean) {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, AgentService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, App.CHANNEL_AGENT)
            .setSmallIcon(R.drawable.ic_agent)
            .setContentTitle(getString(R.string.notif_agent_title))
            .setContentText(getString(R.string.notif_agent_text))
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_agent, "إيقاف", stopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val type =
                if (includeProjection)
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                else
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            try {
                startForeground(NOTIF_ID, notif, type)
            } catch (e: Exception) {
                Log.e(TAG, "startForeground failed (type=$type): ${e.message}")
            }
        } else {
            try { startForeground(NOTIF_ID, notif) } catch (e: Exception) {
                Log.e(TAG, "startForeground (legacy) failed: ${e.message}")
            }
        }
    }

    private fun computeRms(buf: ByteArray): Float {
        var sum = 0.0; var i = 0; val n = buf.size / 2
        while (i < buf.size - 1) {
            val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
            val v = if (s >= 32768) s - 65536 else s
            sum += v.toDouble() * v; i += 2
        }
        return if (n == 0) 0f else (Math.sqrt(sum / n) / 32768.0).toFloat()
    }

    companion object {
        private const val TAG = "AgentService"
        private const val NOTIF_ID = 4242

        const val ACTION_START = "com.arena.geminiagent.START"
        const val ACTION_STOP = "com.arena.geminiagent.STOP"
        const val ACTION_ARM = "com.arena.geminiagent.ARM"
        const val ACTION_SEND_TEXT = "com.arena.geminiagent.SEND_TEXT"

        const val EXTRA_MP_CODE = "mp_code"
        const val EXTRA_MP_INTENT = "mp_intent"
        const val EXTRA_TEXT = "text"

        const val ARMED_WINDOW_MS = 6_000L     // initial gate after wake word / tap
        const val ARMED_EXTEND_MS = 3_000L     // each time user keeps speaking
        const val SPEECH_RMS_THRESHOLD = 0.02f

        fun start(context: Context, mpCode: Int, mpData: Intent?) {
            val i = Intent(context, AgentService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_MP_CODE, mpCode)
                if (mpData != null) putExtra(EXTRA_MP_INTENT, mpData)
            }
            try { context.startForegroundService(i) } catch (_: Exception) {}
        }
        fun stop(context: Context) {
            try {
                context.startService(
                    Intent(context, AgentService::class.java).setAction(ACTION_STOP)
                )
            } catch (_: Exception) {}
        }
        fun arm(context: Context) {
            try {
                context.startService(
                    Intent(context, AgentService::class.java).setAction(ACTION_ARM)
                )
            } catch (_: Exception) {}
        }
        fun sendText(context: Context, text: String) {
            try {
                context.startService(
                    Intent(context, AgentService::class.java)
                        .setAction(ACTION_SEND_TEXT)
                        .putExtra(EXTRA_TEXT, text)
                )
            } catch (_: Exception) {}
        }
    }
}
