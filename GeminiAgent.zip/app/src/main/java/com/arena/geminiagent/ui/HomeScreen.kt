package com.arena.geminiagent.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class HomeState(
    val running: Boolean,
    val statusLabel: String,
    val statusColor: Color,
    val caption: String,
    val apiKeySet: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: HomeState,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onTalkNow: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Gemini Live Agent",
                        fontWeight = FontWeight.SemiBold
                    )
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pads ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pads)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(20.dp))
            PulsingOrb(running = state.running, color = state.statusColor)
            Spacer(Modifier.height(16.dp))
            Text(
                state.statusLabel,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = state.statusColor
            )
            Spacer(Modifier.height(24.dp))

            if (!state.apiKeySet) {
                WarningCard(
                    text = "لم تُدخل مفتاح API بعد. افتح الإعدادات وأضف مفتاحك من Google AI Studio.",
                    actionLabel = "الإعدادات",
                    onAction = onOpenSettings
                )
                Spacer(Modifier.height(16.dp))
            }

            // Caption card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "آخر تفاعل",
                        fontSize = 12.sp,
                        color = Color(0xFF8C8CA0)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        state.caption.ifBlank { "..." },
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Spacer(Modifier.height(24.dp))

            // Primary action
            Button(
                onClick = if (state.running) onStop else onStart,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.running) Color(0xFFC2185B) else MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    if (state.running) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (state.running) "إيقاف الوكيل" else "بدء الوكيل",
                    fontSize = 16.sp, fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onTalkNow,
                enabled = state.running,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("اضغط وتكلم الآن (Push-to-Talk)")
            }

            Spacer(Modifier.height(24.dp))
            TipsCard()
        }
    }
}

@Composable
private fun PulsingOrb(running: Boolean, color: Color) {
    val scale by animateFloatAsState(
        targetValue = if (running) 1.05f else 0.92f,
        label = "scale"
    )
    val animColor by animateColorAsState(color, label = "color")
    Box(
        modifier = Modifier
            .size(140.dp)
            .scale(scale)
            .background(animColor.copy(alpha = 0.2f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .background(animColor.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.GraphicEq,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = Color.White
            )
        }
    }
}

@Composable
private fun WarningCard(text: String, actionLabel: String, onAction: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF4A2A00)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text, modifier = Modifier.weight(1f), fontSize = 13.sp)
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = onAction) { Text(actionLabel, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun TipsCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("✨ كيف تستخدمه؟", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("• ابدأ الوكيل ثم اقبل طلب مشاركة الشاشة.", fontSize = 13.sp)
            Text("• قل: \"يا جيمناي، شو رأيك\" أو اضغط الزر العائم.", fontSize = 13.sp)
            Text("• لن يتكلم إلا عند ندائه — اسأله بحرية.", fontSize = 13.sp)
            Text("• يرى ما على شاشتك ويستجيب فوراً بصوت طبيعي.", fontSize = 13.sp)
        }
    }
}
