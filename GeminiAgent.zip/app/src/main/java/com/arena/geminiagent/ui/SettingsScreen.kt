package com.arena.geminiagent.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arena.geminiagent.data.Settings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: Settings,
    onBack: () -> Unit
) {
    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var wakeWord by remember { mutableStateOf(settings.wakeWord) }
    var voice by remember { mutableStateOf(settings.voice) }
    var liveModel by remember { mutableStateOf(settings.liveModel) }
    var thinkModel by remember { mutableStateOf(settings.thinkModel) }
    var fps by remember { mutableStateOf(settings.screenFps) }
    var lang by remember { mutableStateOf(settings.languageHint) }
    var onlyOnRequest by remember { mutableStateOf(settings.onlyOnRequest) }
    var streamScreen by remember { mutableStateOf(settings.streamScreen) }
    var showOverlay by remember { mutableStateOf(settings.showOverlay) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pads ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pads)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Section("🔑 المفتاح والنماذج") {
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it; settings.apiKey = it },
                    label = { Text("Google AI Studio API Key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = liveModel,
                    onValueChange = { liveModel = it; settings.liveModel = it },
                    label = { Text("Live model (للحوار الصوتي)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "الافتراضي: ${Settings.DEFAULT_LIVE_MODEL}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = thinkModel,
                    onValueChange = { thinkModel = it; settings.thinkModel = it },
                    label = { Text("Heavy-thinking model (REST)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "الافتراضي: ${Settings.DEFAULT_THINK_MODEL}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            Section("🎤 الاستماع والصوت") {
                OutlinedTextField(
                    value = wakeWord,
                    onValueChange = { wakeWord = it; settings.wakeWord = it },
                    label = { Text("كلمة التنبيه") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                DropdownField(
                    label = "صوت الوكيل",
                    value = voice,
                    options = Settings.AVAILABLE_VOICES,
                    onSelect = { voice = it; settings.voice = it }
                )
                Spacer(Modifier.height(8.dp))
                DropdownField(
                    label = "اللغة الأساسية",
                    value = lang,
                    options = listOf("ar", "en"),
                    onSelect = { lang = it; settings.languageHint = it }
                )
                Spacer(Modifier.height(8.dp))
                SwitchRow(
                    "يرد فقط عند ندائه",
                    "لا يتكلم إلا بعد كلمة التنبيه أو الزر العائم.",
                    onlyOnRequest
                ) { onlyOnRequest = it; settings.onlyOnRequest = it }
            }

            Section("🖥️ مراقبة الشاشة") {
                SwitchRow(
                    "إرسال لقطات الشاشة",
                    "يسمح للوكيل برؤية ما تفعله.",
                    streamScreen
                ) { streamScreen = it; settings.streamScreen = it }
                Spacer(Modifier.height(8.dp))
                Text("معدل اللقطات: ${"%.1f".format(fps)} لقطة/ثانية", fontSize = 13.sp)
                Slider(
                    value = fps,
                    onValueChange = { fps = it; settings.screenFps = it },
                    valueRange = 0.2f..1.0f,
                    steps = 7
                )
            }

            Section("🪟 الزر العائم") {
                SwitchRow(
                    "إظهار الزر العائم",
                    "زر يطفو فوق التطبيقات للتحدث السريع.",
                    showOverlay
                ) { showOverlay = it; settings.showOverlay = it }
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("حفظ ورجوع", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DropdownField(
    label: String,
    value: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier
                // Deprecated zero-arg overload but still functional in compose-bom 2024.10.01.
                // When you upgrade BOM, switch to: .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = { Text(opt) },
                    onClick = { onSelect(opt); expanded = false }
                )
            }
        }
    }
}
