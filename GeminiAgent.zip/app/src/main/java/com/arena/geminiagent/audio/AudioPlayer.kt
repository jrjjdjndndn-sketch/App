package com.arena.geminiagent.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

/**
 * Streaming PCM player for Gemini Live audio output: 16-bit LE, 24 kHz, mono.
 * Pushes chunks into a Channel and writes them to an AudioTrack in MODE_STREAM,
 * so playback starts almost immediately. Supports flush() for interruption.
 */
class AudioPlayer {

    companion object {
        const val SAMPLE_RATE = 24_000
        private const val CHANNEL = AudioFormat.CHANNEL_OUT_MONO
        private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
    }

    private val queue = Channel<ByteArray>(capacity = 64)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var track: AudioTrack? = null

    fun start() {
        if (job != null) return
        val minBuf = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL, ENCODING)
            .coerceAtLeast(4096)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(ENCODING)
                    .setChannelMask(CHANNEL)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        t.play()
        job = scope.launch {
            for (chunk in queue) {
                try {
                    t.write(chunk, 0, chunk.size, AudioTrack.WRITE_BLOCKING)
                } catch (_: Exception) { /* track torn down */ }
            }
        }
    }

    /** Enqueue a PCM chunk to be played. */
    fun enqueue(pcm: ByteArray) {
        queue.trySend(pcm)
    }

    /** Stop immediately and drop any pending audio (used when user interrupts). */
    fun flush() {
        try {
            track?.pause()
            track?.flush()
            track?.play()
        } catch (_: Exception) { }
        // Drain any queued chunks
        while (queue.tryReceive().isSuccess) { /* drop */ }
    }

    fun stop() {
        job?.cancel(); job = null
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }

    fun shutdown() {
        stop()
        queue.close()
        scope.cancel()
    }
}
