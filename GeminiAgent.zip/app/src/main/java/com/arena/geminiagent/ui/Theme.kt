package com.arena.geminiagent.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9F7CFF),
    onPrimary = Color.White,
    secondary = Color(0xFF4DD0E1),
    background = Color(0xFF0A0A0F),
    surface = Color(0xFF15151D),
    onBackground = Color(0xFFE8E8F0),
    onSurface = Color(0xFFE8E8F0),
)

@Composable
fun GeminiAgentTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content = content
    )
}
